﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WallOfFame.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WallOfFame.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AchievementController : ControllerBase // skal base være med?
    {
        private readonly AchievementContext _context;

        public AchievementController(AchievementContext context)
        {
            _context = context;

            if (_context.Achievements.Count() == 0)
            {
                //Create a new achievementitem if collection is empty, which means you can`t delete all achievementitems
                _context.Achievements.Add(new Achievement { Type = "Type1" });
                _context.SaveChanges();
            }

        }
        //Get list of achievements
        [HttpGet]
        public ActionResult<List<Achievement>> GetAll()
        {
            return _context.Achievements.ToList();
        }

        //Get achievement by id
        [HttpGet("{id}", Name = "GetAchievement")]
        public ActionResult<Achievement> GetById(int id)
        {
            var achievement = _context.Achievements.Find(id);
            if (achievement == null)
            {
                return NotFound();
            }
            return achievement;
        }
        //Post an achievement
        [HttpPost]
        public IActionResult Create(Achievement achievement)
        {
            _context.Achievements.Add(achievement);
            _context.SaveChanges();

            return CreatedAtRoute("GetAchievement", new { id = achievement.AchievementId }, achievement);
        }
        [HttpPut("{id}")]
        public IActionResult Update(int id, Achievement achievement)
        {
            var achieve = _context.Achievements.Find(id);
            if (achieve == null)
            {
                return NotFound();
            }

            achieve.AchievementId = achievement.AchievementId;
            achieve.Type = achievement.Type;
            achieve.Score = achievement.Score;

            _context.Achievements.Update(achieve);
            _context.SaveChanges();
            return NoContent();
        }
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var achieve = _context.Achievements.Find(id);
            if (achieve == null)
            {
                return NotFound();
            }

            _context.Achievements.Remove(achieve);
            _context.SaveChanges();
            return NoContent();
        }

    } 
}
       