﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace WallOfFame.Models
{
    public class AchievementContext : DbContext
    {
        public AchievementContext(DbContextOptions<AchievementContext> options)
            : base(options)
        {

        }

        public DbSet<Achievement> Achievements { get; set; }
    }
}
