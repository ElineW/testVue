﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WallOfFame.Models
{
    public class Achievement
    {
        public int AchievementId { get; set; }
        public string Type { get; set; }
        public int Score { get; set; }
    }
}
